import React, { Component } from 'react'

export default class Data extends Component{

    state = {
        loading: true
    }

    async componentDidMount(){
        const url = "http://localhost:5000/todo/api/v1.0/tasks"
        const response = fetch(url);
        const jsondata = await response.json();
        console.log(jsondata)
    } 

    render(){
        return <div>
            {this.state.loading ? <div>loading...</div>: <div>person...</div>}
        </div>;
    }
}