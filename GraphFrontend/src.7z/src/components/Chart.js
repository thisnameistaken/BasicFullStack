import React, {Component} from 'react';
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import { connect } from 'react-redux';
///import {chartdata1} from './chartcontainer';
///import {chartdata2} from './chartcontainer';
///import {ready} from './chartcontainer';
let {chartdata1} = [1,2,3];
var {chartdata2} = [1,2,3];
var {ready} = true;



export default class Chart extends Component {

  
  
  constructor(props) {
    super(props);
    this.state =  {
      loading: {ready},
      Chartfirst: this.props.chartdata1,
      Chart2nd: {chartdata2}
    };
    console.log(this.state.chartdata1);
    console.log(this.state.Chartfirst);
  } 

  
  
  
  
render(){
  console.log(this.state.Chartfirst);
const options = {
title: {
        text: 'Zoomable Line Graph'
       },
chart: {
        zoomType: 'x'
},
series: [{
         data: this.state.Chartfirst
        },
        {
         data: this.state.Chartdata2 
        }]}
return (
  
  <div className= "line-series">
      <HighchartsReact
       highcharts={Highcharts}
       constructorType={'chart'}
       options={options} />  
       
  </div>
  
);


}
}
