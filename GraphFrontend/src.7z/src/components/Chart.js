import React, {Component} from 'react';
import Highcharts from 'highcharts/highstock';
import HighchartsReact from 'highcharts-react-official';




export default class Chart extends Component {
  constructor() {
    super();
    this.state =  {
      loading: true,
      chartdata1: null,
      chartdata2: null,
      datedata: null
    };
  } 



 
  componentDidMount() {
    const url = "http://localhost:5000/todo/api/v1.0/stuff";
    fetch(url)
    .then(response => response.json())
        .then(data =>{
          this.setState({ chartdata1: data.stuff[0].data, loading: true });
          this.setState({ chartdata2: data.stuff[1].data, loading: true });
          this.setState({ datedata: data.stuff[0].date, loading: true });
          this.setState({loading: false});})
        }
  
  
render(){
  if(this.state.loading){
    return(
      <div>
        ...loading
      </div>
    )
  }



if(!this.state.loading){  

const options = {
title: {
        text: 'Zoomable Line Graph'
       },
chart: {
        zoomType: 'x'
},
xAxis: {
  
},
yAxis: {
  title: {
      text: 'payment'
  }
},
series: [{
         data: this.state.chartdata1
        },
        {
         data: this.state.chartdata2
        }]}
return (
  
  <div className= "line-series">
      <HighchartsReact
       highcharts={Highcharts}
       constructorType={'chart'}
       options={options} />  
       
  </div>
  
);

}
}
}
