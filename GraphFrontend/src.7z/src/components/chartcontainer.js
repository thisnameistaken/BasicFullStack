import React from 'react'
import Chart from './Chart'
import { connect } from 'react-redux';
import { idText } from 'typescript';

class ChartContainer extends React.Component {
  constructor(props) {
    super(props);
    this.state =  {
      loading: true,
      chartdata1: null,
      chartdata2: null
    };
  } 



 
  componentDidMount() {
    const url = "http://localhost:5000/todo/api/v1.0/stuff";
    fetch(url)
    .then(response => response.json())
        .then(data =>{
          this.setState({ chartdata1: data.stuff[0], loading: true });
          this.setState({ chartdata2: data.stuff[1], loading: true });
          this.setState({ready: false});})
        }
 
};

export default {chartdata1}
export default {ready}
export default {chartdata1}
