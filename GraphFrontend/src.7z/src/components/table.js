import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing(3),
    overflowX: 'auto',
  },
  table: {
    minWidth: 650,
  },
}));

function createData(name, Pay1, Pay2, Pay3) {
  return { name, Pay1, Pay2, Pay3};
}

const rows = [
  createData('John Doe', 159, 6.0, 24),
  createData('Sam Samuel', 237, 9.0, 37),
  createData('Joe Schmo', 262, 16.0, 24),
  createData('Ronald McDonald', 305, 3.7, 67),
  createData('Fred Farmer', 356, 16.0, 49),
];

export default function SimpleTable() {
  const classes = useStyles();

  return (
    <Paper className={classes.root}>
      <Table className={classes.table}>
        <TableHead>
          <TableRow>
            <TableCell>Customers</TableCell>
            <TableCell align="right">First Payment</TableCell>
            <TableCell align="right">Second Payment</TableCell>
            <TableCell align="right">Third Payment</TableCell>
            
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map(row => (
            <TableRow key={row.name}>
              <TableCell component="th" scope="row">
                {row.name}
              </TableCell>
              <TableCell align="right">{row.Pay1}</TableCell>
              <TableCell align="right">{row.Pay2}</TableCell>
              <TableCell align="right">{row.Pay3}</TableCell>
              
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Paper>
  );
}