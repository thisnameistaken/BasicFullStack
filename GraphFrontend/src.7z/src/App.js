import React, {Component} from 'react'
import Main from './components/main';

export default class Login extends Component {
  constructor() {
    super();
    this.state =  {
      loggedin: false,
      trueusername: null,
      truepassword: null,
      loading: true,
      username: "",
      password: ''
    };
    this.handleChange = this.handleChange.bind(this);
    
  } 

  componentDidMount() {
    const url = "http://localhost:5000/todo/api/v1.0/login";
    fetch(url)
    .then(response => response.json())
        .then(data =>{
          this.setState({ trueusername: data.login[0].username , loading: true});
          this.setState({ truepassword: data.login[0].password , loading: true});
          this.setState({loading: false});
        })
      }  

      
handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
}
      

render(){
  if(this.state.loading){
    return(
      <div>
        loading...
      </div>
    )
  }
  if(!this.state.loading){
  console.log(this.state.username);
  console.log(this.state.password);
  if(this.state.username !== this.state.trueusername || this.state.password !== this.state.truepassword){
    return(
      <div>
       <form>
       <label>
        Username 
        <input type="text" name="username" onChange={this.handleChange}/>
        </label>
        <label>
        Password 
        <input type="text" name="password" onChange={this.handleChange}/>
        </label>
      </form>
      </div>
      
);

}

  if(this.state.username === this.state.trueusername && this.state.password === this.state.truepassword){
    return (
      <div className= "Login">
          <Main />
      </div>
  );
  }
}

}
}