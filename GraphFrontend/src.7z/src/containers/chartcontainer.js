import React from 'react'

export default async function ComponentDidMount(chartdata1, chartdata2){
    
    state = {
        loading: true,
        chartdata1: null,
        chartdata2: null
      };

    const url = "http://localhost:5000/todo/api/v1.0/stuff";
    const response = await fetch(url);
    const jsondata = await response.json();
    console.log(jsondata.stuff[0]);
    this.setState({ chartdata1: jsondata.stuff[0], loading: true });
    this.setState({ chartdata2: jsondata.stuff[1], loading: true });
    console.log("componentDidMountFinished");
    console.log(this.state.chartdata1.data);
    this.setState({loading: false}); 

    if(!this.state.loading){
    return{
        chartdata1, chartdata2, loading
    };
    }

} 



  
